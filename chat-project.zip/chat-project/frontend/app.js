// Simple frontend: register, send messages, upload files (base64), poll for new messages.

let userId = null;
let username = null;
let lastTimestamp = 0;

document.addEventListener("DOMContentLoaded", () => {
  const btnRegister = document.getElementById("btnRegister");
  const usernameInput = document.getElementById("username");
  btnRegister.onclick = register;

  document.getElementById("sendBtn").onclick = sendMessage;
  document.getElementById("uploadBtn").onclick = uploadFile;

  // Allow enter to send after registered
  document.getElementById("messageInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendMessage();
  });
});

function register() {
  const uname = document.getElementById("username").value.trim();
  if (!uname) { alert("Please enter a display name"); return; }
  fetch("/api/register", {
    method: "POST",
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: "username=" + encodeURIComponent(uname)
  }).then(r => r.json()).then(resp => {
    if (resp.userId) {
      userId = resp.userId; username = resp.username;
      document.getElementById("login").classList.add("hidden");
      document.getElementById("chatApp").classList.remove("hidden");
      document.getElementById("myName").innerText = username;
      // start polling
      pollLoop();
    } else {
      alert("Register failed");
    }
  }).catch(err => {
    console.error(err); alert("Failed to register");
  });
}

function sendMessage() {
  if (!userId) { alert("Please join first"); return; }
  const text = document.getElementById("messageInput").value.trim();
  if (!text) return;
  const body = "userId=" + encodeURIComponent(userId) + "&text=" + encodeURIComponent(text);
  fetch("/api/send", {
    method: "POST",
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  }).then(r => r.json()).then(resp => {
    document.getElementById("messageInput").value = "";
    // Immediately poll once to show the message
    pollOnce();
  }).catch(err => console.error(err));
}

function uploadFile() {
  if (!userId) { alert("Please join first"); return; }
  const fileEl = document.getElementById("fileInput");
  if (!fileEl.files || fileEl.files.length === 0) { alert("Choose a file first"); return; }
  const f = fileEl.files[0];
  const reader = new FileReader();
  reader.onload = function(ev) {
    const dataUrl = ev.target.result; // data:*/*;base64,...
    const base64 = dataUrl.split(",")[1];
    // prepare JSON with keys userId, filename, contentBase64
    const payload = JSON.stringify({
      userId,
      filename: f.name,
      contentBase64: base64
    });
    fetch("/api/upload", {
      method: "POST",
      headers: { 'Content-Type': 'application/json' },
      body: payload
    }).then(r => r.json()).then(resp => {
      // file uploaded; poll to see message
      pollOnce();
      fileEl.value = "";
    }).catch(err => console.error(err));
  };
  reader.readAsDataURL(f);
}

function pollLoop() {
  setInterval(pollOnce, 2000); // every 2 seconds
  pollOnce();
}

function pollOnce() {
  fetch("/api/messages?since=" + lastTimestamp)
    .then(r => r.json())
    .then(data => {
      if (!data.messages) return;
      const container = document.getElementById("messages");
      for (const m of data.messages) {
        appendMessage(m);
        if (m.timestamp > lastTimestamp) lastTimestamp = m.timestamp;
      }
      document.getElementById("lastTS").innerText = lastTimestamp;
      container.scrollTop = container.scrollHeight;
    })
    .catch(err => console.error(err));
}

function appendMessage(m) {
  const container = document.getElementById("messages");
  const div = document.createElement("div");
  div.classList.add("message");
  if (m.senderId === userId) div.classList.add("mine");
  const meta = document.createElement("div");
  meta.classList.add("meta");
  const date = new Date(m.timestamp);
  meta.innerText = `${m.senderName} • ${date.toLocaleTimeString()}`;
  div.appendChild(meta);

  const text = document.createElement("div");
  // if message has filename, render link
  if (m.filename && m.filepath) {
    const p = document.createElement("p");
    p.innerText = m.text;
    const a = document.createElement("a");
    a.href = "/static/" + m.filepath; // server will serve
    a.target = "_blank";
    a.className = "file-link";
    a.innerText = m.filename + " (download)";
    div.appendChild(p);
    div.appendChild(a);
  } else {
    text.innerText = m.text;
    div.appendChild(text);
  }

  container.appendChild(div);
}
