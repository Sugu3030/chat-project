package storage;

import model.Message;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MessageStore {
    private final List<Message> messages = new ArrayList<>();
    private long nextId = 1;
    private final File historyFile;

    public MessageStore(File historyFile) {
        this.historyFile = historyFile;
        // create file if not exists
        try {
            if (!historyFile.exists()) {
                historyFile.getParentFile().mkdirs();
                historyFile.createNewFile();
            } else {
                // Optionally load previous history - simple append only for now
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public synchronized Message addMessage(String senderId, String senderName, String text, String filename, String filepath) {
        long ts = System.currentTimeMillis();
        Message m = new Message(nextId++, senderId, senderName, text, ts, filename, filepath);
        messages.add(m);
        appendToHistory(m);
        return m;
    }

    public synchronized List<Message> getMessagesSince(long sinceTimestamp) {
        List<Message> out = new ArrayList<>();
        for (Message m : messages) {
            if (m.getTimestamp() > sinceTimestamp) out.add(m);
        }
        return out;
    }

    private void appendToHistory(Message m) {
        try (FileWriter fw = new FileWriter(historyFile, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(m.toJson());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
