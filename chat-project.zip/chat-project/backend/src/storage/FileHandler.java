package storage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;

public class FileHandler {
    private final File baseDir;

    public FileHandler(File baseDir) {
        this.baseDir = baseDir;
        if (!baseDir.exists()) baseDir.mkdirs();
    }

    /**
     * Saves base64 file content to disk. Returns the relative filepath (for the server to serve).
     */
    public synchronized String saveBase64File(String filename, String base64content) throws IOException {
        // sanitize filename minimally
        String safeName = filename.replaceAll("[^a-zA-Z0-9._-]", "_");
        String nameWithTs = System.currentTimeMillis() + "_" + safeName;
        File outFile = new File(baseDir, nameWithTs);
        byte[] data = Base64.getDecoder().decode(base64content);
        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            fos.write(data);
        }
        // return relative path used by the server to serve files
        return "shared_files/" + outFile.getName();
    }
}
