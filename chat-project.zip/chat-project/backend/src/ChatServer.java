import com.sun.net.httpserver.*;

import model.User;
import model.Message;
import storage.MessageStore;
import storage.FileHandler;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Executors;

/**
 Simple HTTP server that serves frontend and exposes REST-like endpoints.
 Compile with: javac -d out src/ Run: java -cp out ChatServer

 **/
public class ChatServer {
    // simple in-memory user map (id -> User)
    private final Map<String, User> users = Collections.synchronizedMap(new HashMap<>());
    private final MessageStore messageStore;
    private final FileHandler fileHandler;
    private final int port;

    public ChatServer(int port) {
        this.port = port;
        File history = new File("backend/chat_history.txt");
        this.messageStore = new MessageStore(history);
        this.fileHandler = new FileHandler(new File("backend/shared_files"));
    }

    public void start() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", this::handleRoot);
        server.createContext("/static/", this::handleStatic);
        server.createContext("/api/register", this::handleRegister);
        server.createContext("/api/send", this::handleSend);
        server.createContext("/api/messages", this::handleMessages);
        server.createContext("/api/upload", this::handleUpload);
        server.setExecutor(Executors.newCachedThreadPool());
        System.out.println("Server starting on port " + port);
        server.start();
    }

    // Serve index
    private void handleRoot(HttpExchange exchange) throws IOException {
        if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
            sendResponse(exchange, 405, "Method Not Allowed");
            return;
        }
        File index = new File("frontend/index.html");
        if (!index.exists()) {
            sendResponse(exchange, 500, "index.html not found. Put frontend files in frontend/");
            return;
        }
        byte[] bytes = readFileBytes(index);
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
        sendBytes(exchange, 200, bytes);
    }

    private void handleStatic(HttpExchange exchange) throws IOException {
        if (!exchange.getRequestMethod().equalsIgnoreCase("GET")) {
            sendResponse(exchange, 405, "Method Not Allowed");
            return;
        }
        String path = exchange.getRequestURI().getPath();
        // path like /static/styles.css or /static/app.js or /static/shared_files/...
        String relative = path.replaceFirst("/static/", "");
        File file = new File("frontend/" + relative);
        if (!file.exists()) {
            // maybe serve backend shared_files
            file = new File(relative); // try relative path (e.g., shared_files/...)
        }
        if (!file.exists()) {
            sendResponse(exchange, 404, "Not found: " + relative);
            return;
        }
        String ct = contentTypeForName(file.getName());
        exchange.getResponseHeaders().add("Content-Type", ct);
        byte[] bytes = readFileBytes(file);
        sendBytes(exchange, 200, bytes);
    }

    private String contentTypeForName(String name) {
        if (name.endsWith(".css")) return "text/css; charset=utf-8";
        if (name.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (name.endsWith(".html")) return "text/html; charset=utf-8";
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
        if (name.endsWith(".txt")) return "text/plain; charset=utf-8";
        if (name.endsWith(".json")) return "application/json; charset=utf-8";
        return "application/octet-stream";
    }

    private void handleRegister(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendResponse(exchange, 405, "Method Not Allowed");
            return;
        }
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        // expecting form: username=...
        String username = parseForm(body).getOrDefault("username", "").trim();
        if (username.isEmpty()) {
            sendResponse(exchange, 400, "{\"error\":\"username required\"}");
            return;
        }
        User u = new User(username);
        users.put(u.getId(), u);
        String json = "{\"userId\":\"" + u.getId() + "\",\"username\":\"" + escape(u.getUsername()) + "\"}";
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        sendResponse(exchange, 200, json);
    }

    private void handleSend(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendResponse(exchange, 405, "Method Not Allowed");
            return;
        }
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> form = parseForm(body);
        String userId = form.getOrDefault("userId", "");
        String text = form.getOrDefault("text", "");
        if (userId.isEmpty() || text.isEmpty()) {
            sendResponse(exchange, 400, "{\"error\":\"userId and text required\"}");
            return;
        }
        User u = users.get(userId);
        if (u == null) {
            sendResponse(exchange, 400, "{\"error\":\"invalid userId\"}");
            return;
        }
        Message m = messageStore.addMessage(u.getId(), u.getUsername(), text, null, null);
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        sendResponse(exchange, 200, "{\"status\":\"ok\",\"messageId\":" + m.getId() + "}");
    }

    private void handleMessages(HttpExchange exchange) throws IOException {
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendResponse(exchange, 405, "Method Not Allowed");
            return;
        }
        String query = exchange.getRequestURI().getQuery();
        long since = 0L;
        if (query != null) {
            for (String kv : query.split("&")) {
                String[] parts = kv.split("=", 2);
                if (parts.length == 2 && parts[0].equals("since")) {
                    try { since = Long.parseLong(parts[1]); } catch (NumberFormatException ignored) {}
                }
            }
        }
        List<Message> msgs = messageStore.getMessagesSince(since);
        StringBuilder sb = new StringBuilder();
        sb.append("{\"messages\":[");
        for (int i = 0; i < msgs.size(); i++) {
            sb.append(msgs.get(i).toJson());
            if (i < msgs.size() - 1) sb.append(",");
        }
        sb.append("]}");
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        sendResponse(exchange, 200, sb.toString());
    }

    private void handleUpload(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendResponse(exchange, 405, "Method Not Allowed");
            return;
        }
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        // expecting simple JSON: {"userId":"...","filename":"...","contentBase64":"..."}
        String userId = extractJsonString(body, "userId");
        String filename = extractJsonString(body, "filename");
        String contentBase64 = extractJsonString(body, "contentBase64");
        if (userId == null || filename == null || contentBase64 == null) {
            sendResponse(exchange, 400, "{\"error\":\"userId, filename and contentBase64 required\"}");
            return;
        }
        User u = users.get(userId);
        if (u == null) {
            sendResponse(exchange, 400, "{\"error\":\"invalid userId\"}");
            return;
        }
        try {
            String savedRelPath = fileHandler.saveBase64File(filename, contentBase64);
            // create a message referencing the file
            Message m = messageStore.addMessage(u.getId(), u.getUsername(), u.getUsername() + " shared a file: " + filename, filename, savedRelPath);
            String resp = "{\"status\":\"ok\",\"messageId\":" + m.getId() + ",\"filepath\":\"" + savedRelPath + "\"}";
            exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
            sendResponse(exchange, 200, resp);
        } catch (IOException ex) {
            ex.printStackTrace();
            sendResponse(exchange, 500, "{\"error\":\"failed to save file\"}");
        }
    }

    // helpers
    private void sendResponse(HttpExchange exchange, int code, String body) throws IOException {
        byte[] bs = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(code, bs.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bs);
        }
    }

    private void sendBytes(HttpExchange exchange, int code, byte[] bytes) throws IOException {
        exchange.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private byte[] readFileBytes(File f) throws IOException {
        return java.nio.file.Files.readAllBytes(f.toPath());
    }

    private Map<String, String> parseForm(String body) {
        Map<String, String> map = new HashMap<>();
        if (body == null || body.isEmpty()) return map;
        // assume form-encoded: key=val&key2=val2
        String[] pairs = body.split("&");
        for (String p : pairs) {
            String[] kv = p.split("=", 2);
            if (kv.length == 2) {
                map.put(urlDecode(kv[0]), urlDecode(kv[1]));
            }
        }
        return map;
    }

    private String urlDecode(String s) {
        try {
            return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8.name());
        } catch (UnsupportedEncodingException e) {
            return s;
        }
    }

    private String extractJsonString(String json, String key) {
        // very small helper: not a full JSON parser. Looks for "key":"value"
        String pattern = "\"" + key + "\"";
        int idx = json.indexOf(pattern);
        if (idx == -1) return null;
        int colon = json.indexOf(":", idx);
        if (colon == -1) return null;
        int quoteStart = json.indexOf("\"", colon);
        if (quoteStart == -1) return null;
        int quoteEnd = json.indexOf("\"", quoteStart + 1);
        if (quoteEnd == -1) return null;
        return json.substring(quoteStart + 1, quoteEnd).replace("\\\"", "\"").replace("\\n", "\n");
    }

    private String escape(String s) {
        return s.replace("\"", "\\\"").replace("\n", "\\n");
    }

    public static void main(String[] args) throws IOException {
        int port = 8000;
        ChatServer server = new ChatServer(port);
        server.start();
    }
}
