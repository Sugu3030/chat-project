package model;

public class Message {
    private final long id;
    private final String senderId;
    private final String senderName;
    private final String text;
    private final long timestamp;
    private final String filename; // optional if message references a file
    private final String filepath; // server-side path for file (used by frontend to download)

    public Message(long id, String senderId, String senderName, String text, long timestamp, String filename, String filepath) {
        this.id = id;
        this.senderId = senderId;
        this.senderName = senderName;
        this.text = text;
        this.timestamp = timestamp;
        this.filename = filename;
        this.filepath = filepath;
    }

    public long getId() {
        return id;
    }

    public String getSenderId() {
        return senderId;
    }

    public String getSenderName() {
        return senderName;
    }

    public String getText() {
        return text;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getFilename() {
        return filename;
    }

    public String getFilepath() {
        return filepath;
    }

    // Converts to a JSON string (simple manual JSON)
    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"id\":").append(id).append(",");
        sb.append("\"senderId\":\"").append(escape(senderId)).append("\",");
        sb.append("\"senderName\":\"").append(escape(senderName)).append("\",");
        sb.append("\"text\":\"").append(escape(text)).append("\",");
        sb.append("\"timestamp\":").append(timestamp).append(",");
        sb.append("\"filename\":").append(filename == null ? "null" : "\"" + escape(filename) + "\"").append(",");
        sb.append("\"filepath\":").append(filepath == null ? "null" : "\"" + escape(filepath) + "\"");
        sb.append("}");
        return sb.toString();
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
